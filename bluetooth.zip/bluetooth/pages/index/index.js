
const app = getApp()
const Util = require('../../utils/util.js')

Page({
  data: {
    available: false,
    discovering: false,
    deviceId: '',
    serviceId: '',
    characteristicId: '',
    devices: [],
    deviceIndex: 0,
  },
  onLoad() {
    // console.log(Util.md5('123'))
  },
  opendoor() {
    if (this.data.deviceId) {
      this.connectBluetooth()
    } else {
      this.initBluetooth()
    }
  },
  initBluetooth() {
    let that = this;
    wx.openBluetoothAdapter({
      success(res) {
        console.log("初始化蓝牙模块 --- 已开启")
        that.watchBluetoothStateChange()
        that.searchBluetooth()
      },
      fail(err) {
        console.log("初始化蓝牙模块 --- 未开启")
        that.watchBluetoothStateChange()
        if (err.errCode == 10001) {
          wx.showToast({
            title: '蓝牙未开启',
            icon: 'none'
          })
        }
      }
    })
  },
  /**
   * 监听蓝牙适配器状态变化事件
   */
  watchBluetoothStateChange() {
    let that = this;
    wx.onBluetoothAdapterStateChange((res) => {
      console.log("监听蓝牙状态改变")
      console.log(res)
      /**
       * 搜索状态
       */
      if (that.data.discovering != res.discovering) {
        that.setData({
          discovering: res.discovering
        })
      }
      /**
       * 蓝牙状态
       */
      if (that.data.available != res.available) {
        that.setData({
          available: res.available
        })
        if (!res.available) {
          wx.showToast({
            title: '蓝牙未开启',
            icon: 'none'
          })
          console.log('蓝牙适配器不可用')
        } else {
          if (!res.discovering && !that.data.devices.length) {
            that.searchBluetooth()
          }
        }
      }
    })
  },
  /**
   * 查找设备
   */
  searchBluetooth() {
    let that = this;
    wx.startBluetoothDevicesDiscovery({
      allowDuplicatesKey: false,
      success(res) {
        console.log("查找设备")
        that.watchBluetoothFound()
        setTimeout(that.stopSearchBluetooth, 5000)
      }
    })
  },
  /**
   * 监听寻找到新设备
   */
  watchBluetoothFound() {
    let that = this;
    wx.onBluetoothDeviceFound(function (res) {
      let device = res.devices[0]
      if (device && device.localName == 'JDY-16') {
        console.log("查找到JDY-16")
        let devices = that.data.devices
        devices.push(device.deviceId)
        that.setData({ devices: devices })
        that.connectBluetooth()
      }
    })
  },
  /**
   * 停止查找
   */
  stopSearchBluetooth() {
    let that = this;
    wx.stopBluetoothDevicesDiscovery({
      success: function (res) {
        console.log("停止查找")
      }
    })
  },
  /**
   * 获取设备列表
   */
  getBluetoothDevices() {
    let that = this;
    wx.getBluetoothDevices({
      success: function (res) {
        console.log('获取已发现的蓝牙设备')
        console.log(res.devices)
        let devices = res.devices.filter((item) => item.localName == "JDY-16")
        if (devices.length) {
          that.setData({
            devices: devices
          })
          console.log(that.data.devices)
        }
      }
    })
  },
  /**
   * 连接设备
   */
  connectBluetooth() {
    let that = this;
    wx.createBLEConnection({
      deviceId: that.data.devices[that.data.deviceIndex],
      success(res) {
        console.log("连接成功 设备 " + that.data.deviceIndex)
        that.getBluetoothServers()
      },
      fail(err) {
        let deviceIndex = that.data.deviceIndex;
        if (that.data.devices.length - 1 > deviceIndex) {
          console.log("连接失败，连接下一个设备")
          that.setData({ deviceIndex: deviceIndex + 1 })
          that.connectBluetooth()
        } else {
          console.log("连接失败，结束")
        }
      }
    })
  },
  /**
   * 断开连接
   */
  closeConnectBluetooth() {
    let that = this;
    wx.closeBLEConnection({
      deviceId: that.data.devices[that.data.deviceIndex],
      success(res) {
        console.log("手动断开连接")
      }
    })
  },
  /**
   * 获取设备服务
   */
  getBluetoothServers() {
    let that = this;
    wx.getBLEDeviceServices({
      deviceId: that.data.devices[that.data.deviceIndex],
      success(res) {
        console.log(res.services)
        that.setData({ serviceId: res.services[0].uuid })
        that.getBluetoothCharacteristics()
      },
    })
  },
  /**
   * 获取设备某个服务特征值列表
   */
  getBluetoothCharacteristics() {
    let that = this;
    wx.getBLEDeviceCharacteristics({
      deviceId: that.data.devices[that.data.deviceIndex],
      serviceId: that.data.serviceId,
      success(res) {
        that.setData({ characteristicId: res.characteristics[0].uuid })
        that.notifyBluetoothCharacteristicValueChange()
        // for (let i = 0; i < res.characteristics.length; i++) {
        //   if (res.characteristics[i].properties.write) {
        //     console.log(res.characteristics[i])
        //     that.setData({ characteristicId: res.characteristics[i].uuid })
        //     that.notifyBluetoothCharacteristicValueChange()
        //     break
        //   }
        // }
      },
    })
  },
  /**
   * 向设备特征值中写入二进制数据
   */
  writeBluetoothCharacteristicValue(type) {
    let that = this;
    if (type == '01') {
      var str = Util.md5("5678") + "cd12345678"
      var arr = that.strToHex(str)
      var buffer = that.strToBuf(arr, type)
    } else if (type == '02') {
      var str = Util.md5("5678cd12345678666666")
      var arr = that.strToHex(str)
      var buffer = that.strToBuf(arr, type)
    } else {
      console.log('参数错误')
      return false
    }
    
    wx.writeBLECharacteristicValue({
      deviceId: that.data.devices[that.data.deviceIndex],
      serviceId: that.data.serviceId,
      characteristicId: that.data.characteristicId,
      value: buffer,
      success(res) {
        console.log("写入成功")
      },
      fail(res) {
        let deviceIndex = that.data.deviceIndex;
        if (that.data.devices.length - 1 > deviceIndex) {
          console.log("写入失败 连接下一个设备")
          that.setData({ deviceIndex: deviceIndex + 1 })
          that.connectBluetooth()
        } else {
          console.log("写入失败 结束")
        }
      }
    })
  },
  /**
   * 启用设备特征值变化时的 notify 功能
   */
  notifyBluetoothCharacteristicValueChange() {
    let that = this;
    wx.notifyBLECharacteristicValueChange({
      deviceId: that.data.devices[that.data.deviceIndex],
      serviceId: that.data.serviceId,
      characteristicId: that.data.characteristicId,
      state: true,
      type: 'notification',
      success(res) {
        console.log("启用设备特征值变化时的 notify 功能")
        that.watchBluetoothCharacteristicValueChange()
      },
    })
  },
  /**
   * 监听设备的特征值变化
   */
  watchBluetoothCharacteristicValueChange() {
    let that = this;
    console.log("监听设备的特征值变化")
    wx.onBLECharacteristicValueChange(function (res) {
      console.log("监听到返回信息")
      console.log(that.hexToStr(that.buf2hex(res.value)))
      if (that.hexToStr(that.buf2hex(res.value)) == '666666') {
        that.setData({ deviceId: that.data.devices[that.data.deviceIndex] })
        that.writeBluetoothCharacteristicValue('02')
      } else if (that.hexToStr(that.buf2hex(res.value)) == '200') {
        that.closeConnectBluetooth()
      }
    })
    setTimeout(() => {
      that.writeBluetoothCharacteristicValue('01')
    }, 20)
  },
  /**
   * ArrayBuffer转16进制
   */
  buf2hex(buffer) {
    return Array.prototype.map.call(new Uint8Array(buffer), x => x)
  },
  /**
   * 字符串转hex
   */
  strToHex(str) {
    var arr = [];
    for (var i = 0; i < str.length; i++) {
      arr.push(str.charCodeAt(i).toString(16))
    }
    return arr
  },
  /**
   * hex转ArrayBuffer
   */
  strToBuf(arr, type) {
    var length = arr.length
    var buffer = new ArrayBuffer(length + 2)
    var dataview = new DataView(buffer)
    dataview.setUint8(0, '0x' + type)
    dataview.setUint8(1, '0x' + (length > 16 ? length.toString(16) : '0' + length.toString(16)))
    for (let i = 0; i < length; i++) {
      dataview.setUint8(i + 2, '0x' + arr[i])
    }
    return buffer
  },
  /**
   * hex转字符串
   */
  hexToStr(hex) {
    let arr = Array.prototype.map.call(hex, x => String.fromCharCode(x))
    return arr.join('')
  }
})
