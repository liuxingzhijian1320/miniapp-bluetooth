const md5 =require('./md5.js');

module.exports = {
  md5: md5
}
